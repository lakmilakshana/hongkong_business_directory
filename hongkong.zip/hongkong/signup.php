<?php
   
   require_once("include/connect.php"); 
   session_start();
   error_reporting (0);

    if(isset($_POST['submit'])){

        $name = $_POST['name'];
        $role = $_POST['role'];
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $cpassword = md5($_POST['cpassword']);

        if($password == $cpassword){
            $sql = "SELECT * FROM users WHERE username = '$username'";
            $result =  mysqli_query($connect, $sql);

            if(!$result -> num_rows > 0){
                $sql = "INSERT INTO users (name,role,username,password) VALUES ('$name','$role','$username','$password')";
                $result = mysqli_query($connect, $sql);
                if($result){
                    
                    echo "<script>alert('User Regsitration Completed.')</script>";
                    //Define variables and initialize with empty values
                    $name ="";
                    $role="";
                    $username="";
                    $_POST['password']="";
                    $_POST['cpassword']="";
                    
                }else{
                    echo '<script>alert("Registered Successfully.")</script>';
                    echo "<script>window.location.href ='login.php'</script>";
                }
            }else{
                 echo "<script>alert('Email Already Exists')</script>";
            } 
        }
    }
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Find Buisness</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--bootstrap4 library linked-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <!--custom style-->
  <style type="text/css">
    .container-fluid{
      background-image: url(./images/img005.jpg);
      background-size:cover;
    }
    .text-center{
      font-weight:bold;
      font-family: Arial, Helvetica, sans-serif;
    }
    h4{
      font-weight:bold;
      font-family: Arial, Helvetica, sans-serif;
      font-style:italic;
      font-size:35px;
      color:#061356;
    }
   .registration-form{
      background: #ffffff;
      padding: 20px;
      margin: 100px 0px;
      border-radius:20px;
    }
    .err-msg{
      color:red;
    }
    .registration-form form{
      padding: 10px;
      
    }
    .btn-secondary{
      background-color:#17c914 ;
      text-align:center;
      margin:auto;
      display:flex;
      border:none;
    }
    #login{
      color:#f7b515;
      text-decoration: none;
    }
   
 
  </style>
</head>
<body>
<div class="container-fluid">
 <div class="row">
   <div class="col-sm-4"></div>
      <div class="col-sm-4">
        <div class="registration-form">
          <h4 class="text-center">Sign Up</h4>
          <br>
          <p class="text-success text-center">Already Have an Account ? <a id="login" href="login.php">Login </a></p>
          <p class="text-success text-center"></p>
          <form action="signup.php" method="post">
          <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control"  placeholder="Enter First Name" name="name" value="<?php echo $fname; ?>" required>
          </div>
          <div class="form-group mb-0">
                    <label>Select User Type:</label>
                </div>
                <select class="form-control mb-3" name="role">
                    <option selected value="user"> User</option>
                    <option value="admin">Admin</option>
                </select>
          <div class="form-group">
            <label>Username:</label>
            <input type="text" class="form-control"  placeholder="Enter Username " name="username" value="<?php echo $username; ?>" required>
          </div>
        
        <div class="form-group">
            <label>Create Password:</label>
            <input type="password" class="form-control" name="password" value="<?php echo $_POST['password']; ?>" required>
        </div>
        <div class="form-group">
            <label>Confirm Password:</label>
            <input type="password" class="form-control" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>
        </div>
          <button type="submit" class="btn btn-secondary" name="submit">Sign Up</button>
      </form>
    </div>
   </div>
   <div class="col-sm-4"></div>
 </div>
</div>
<footer>
  <div class="container">
    <div class="col-lg-12">
      <div class="sub-footer">
        <p style="padding-left:300px;margin-top:1%;">Copyright © 2022 Bluechip Technologies Asia Limited. All Rights Reserved.
      </div>
    </div>
  </div>
  </footer>
</body>
</html>