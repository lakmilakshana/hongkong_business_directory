
<?php

include_once('../include/connect.php');

session_start();


if(isset($_GET['delete_cat'])){
    $id = $_GET['delete_cat'];
    $result = runQuery("DELETE FROM categories WHERE cat_id='$id'");
    
    
    if($result)
    {
        
        echo '<script>alert("Delete Category successfully.")</script>';
    					echo "<script>window.location.href ='category_details.php'</script>";;
    }
    else{
        echo "fail";
    }
}
?>