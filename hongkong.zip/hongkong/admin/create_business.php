<?php require_once("../include/connect.php"); 

?>
	
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Admin Create Business Listing on Find Business Directory</title>
	<!-- CSS only -->
	<link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

<style>
   .registration-form{
      background: #f7f7f7;
      padding: 20px;
     
      margin: 100px 0px;
    }
    .err-msg{
      color:red;
    }
    .registration-form form{
      border: 1px solid #e8e8e8;
      padding: 10px;
      background: #f3f3f3;
    }
</style>
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default top-navbar" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
				<a href=index.php Rel=”nofollow” class="navbar-brand">HongKong | Business Directory </a>
        </div>
    </nav>
        <!--/. NAV TOP  -->
    <nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
                <li>
                    <a  href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <li> 
					<a class="active-menu" href="create_business.php"><i class="fa fa-pencil-square-o"></i> Insert Business</a>
                </li>
				<li> 
					<a href="category.php"><i class="fa fa-keyboard-o"></i> Insert Category</a>
                </li>
				<li>
                    <a href="business_details.php"><i class="fa fa-list"></i> Business Records</a>
                </li>
                <li>
                    <a href="category_details.php"><i class="fa fa-table"></i> Manage Category Details</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                </li>
			</ul>
        </div>
    </nav>
	<div id="page-wrapper">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">Add Business</h1>
                </div>
            </div>

		<?php 
			if(isset($_POST['insert'])){

				$title  = $_POST['title'];
				$owner  = $_POST['owner'];
				$primary_contact  = $_POST['primary_contact'];
				$secondary_contact  = $_POST['secondary_contact'];
				$email  = $_POST['email'];
				$category  = $_POST['category'];
				$description  = $_POST['description'];
				$street  = $_POST['street'];
				$city  = $_POST['city'];
				$state  = $_POST['state'];
				$pincode  = $_POST['pincode'];
   
				//image work and validation
				
				//image name
				$image1  = $_FILES['image1']['name'];
				$image2  = $_FILES['image2']['name'];
				
				//image tmp name

				$tmp_image1  = $_FILES['image1']['tmp_name'];
				$tmp_image2  = $_FILES['image2']['tmp_name'];
				
				move_uploaded_file($tmp_image1,"../photo/$image1");
				move_uploaded_file($tmp_image2,"../photo/$image2");

				$query = "INSERT INTO records (title,owner,primary_contact,secondary_contact,email,category,description,street,city,state,pincode,image1,image2) 
				value('$title','$owner','$primary_contact','$secondary_contact','$email','$category','$description','$street','$city','$state','$pincode','$image1','$image2')";

				if(runQuery($query)){
					echo '<script>alert("Business Registered Successfully.")</script>';
    					echo "<script>window.location.href ='business_details.php'</script>";;
				}
				else{
					echo "fail";
				}
		}
?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="panel-group" id="accordion">
					<form action="create_business.php" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<label>Business Title</label>
							<input type="text" name="title" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['title'];}?>">
						</div>
						<div class="form-group">
							<label>Owner Name</label>
							<input type="text" name="owner" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['owner'];}?>">
						</div>
						<div class="form-group">
							<label>Primary Contact</label>
							<input type="text" name="primary_contact" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['primary_contact'];}?>">
						</div>
						<div class="form-group">
							<label>Secondary Contact</label>
							<input type="text" name="secondary_contact" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['secondary_contact'];}?>">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="text" name="email" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['email'];}?>">
						</div>
						<div class="form-group">
							<label>Category</label>
								<select name="category" class="form-control">
							<?php 
								$cat_calling = callingQuery("select * from categories");
								foreach($cat_calling as $cat):
							?>
									<option value="<?= $cat['cat_id'];?>"><?= $cat['cat_title'];?></option>
									<?php endforeach;?>
								</select>
						</div>
						<div class="form-group">
							<label>Business Description</label>
							<textarea rows="5" name="description" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['description'];}?>"></textarea>
						</div>
						<div class="form-group">
							<label>Street</label>
							<input type="text" name="street" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['street'];}?>">
						</div>
						<div class="form-group">
							<label>City</label>
							<input type="text" name="city" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['city'];}?>">
						</div>
						<div class="form-group">
							<label>State</label>
							<input type="text" name="state" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['state'];}?>">
						</div>
						<div class="form-group">
							<label>Zip code</label>
							<input type="text" name="pincode" class="form-control" value="<?php if(isset($_POST['insert'])){echo $_POST['pincode'];}?>">
						</div>
			
						<div class="form-group">
							<label>Image 1</label>
							<input type="file" name="image1" class="form-control" >
						</div>
						<div class="form-group">
							<label>Image 2</label>
							<input type="file" name="image2" class="form-control" >
						</div>
						<div class="mb-3">
							<input type="submit" name="insert" class="btn btn-success btn-block" value="Add Business">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

	<script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
</body>
<footer>
  <div class="container">
    <div class="col-lg-9">
      <div>
        <p style="padding-left:300px;">Copyright © 2022 Bluechip Technologies Asia Limited. All Rights Reserved.
      </div>
    </div>
  </div>
  </footer>
</html>