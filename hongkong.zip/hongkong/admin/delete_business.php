<?php 

require_once("../include/connect.php"); 
session_start();


if(isset($_GET['delete_business'])){
	$id = $_GET['delete_business'];

	$query = runQuery("DELETE FROM records where b_id = '$id'");

	if($query){
		echo '<script>alert("Delete Business successfully.")</script>';
    					echo "<script>window.location.href ='business_details.php'</script>";;
	}
	else{
		echo "not deleted";
	}
}

?>