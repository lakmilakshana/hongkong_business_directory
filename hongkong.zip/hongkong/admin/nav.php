
<div class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container">

	<a href="index.php" class="navbar-brand">HongKong | Business Directory</a>

	<ul class="navbar-nav ml-auto">

		<?php 
		if(isset($_SESSION['admin_log'])):?>
		<li class="nav-item">
			<a class="active-menu" href="logout.php" class="btn btn-danger">Logout</a>
		</li>
		<?php else: ?>
		<?php endif;?>
	</ul>
</div>
</div>