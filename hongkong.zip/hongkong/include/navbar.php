
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="navbar navbar-expand-lg navbar-dark bg-primary">
	<div class="container">

	<a href="index.php" class="navbar-brand">HongKong BDW</a>

	<form class="d-flex my-auto mx-auto" action="index.php" method="get">

		<input class="form-control" name="search" type="text" placeholder="Search" size="60">
		<button class="btn btn-danger" name="find" type="submit"><i class="fa fa-search"></i></button>
		
		<a href="contact_us.php" class="navbar-brand">Contact Us</a>

	</form>

	<ul class="navbar-nav ml-auto">
		<li class="nav-item">
			<a href="login.php" class="navbar-brand">Login</a>
					
		</li>
		

	</ul>
</div>
</div>