<nav class="navbar navbar-expand-lg bg-primary navbar-dark">
   <div class="container">
    <a href="index.php" class="navbar-brand">HongKong | Findbusiness</a>
    
    <form action="" class="d-flex my-auto mx-auto">
       <input type="search" class="form-control form-control-sm" name="search" placeholder="search business" size="60">
       <input type="submit" name="send" value="find" class="btn btn-danger btn-sm ml-2">
      
    </form>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
        
       
    </ul>
    </div>
</nav>